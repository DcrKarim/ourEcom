export const environment = {
  apiURL: 'https://fakestoreapi.com',
  stripeAPIKey: '',
  serverURL: 'http://localhost:4242',
};
